# Guides

```{toctree}
---
hidden:
---

introducing_black_to_your_project
using_black_with_other_tools
```

Wondering how to do something specific? You've found the right place! Listed below are
topic specific guides available:

- {doc}`introducing_black_to_your_project`
- {doc}`using_black_with_other_tools`
