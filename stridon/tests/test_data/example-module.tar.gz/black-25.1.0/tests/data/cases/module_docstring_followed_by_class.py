"""Two blank lines between module docstring and a class."""
class MyClass:
    pass

# output
"""Two blank lines between module docstring and a class."""


class MyClass:
    pass
