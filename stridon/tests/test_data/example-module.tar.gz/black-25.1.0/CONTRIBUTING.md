# Contributing to _Black_

Welcome future contributor! We're happy to see you willing to make the project better.

If you aren't familiar with _Black_, or are looking for documentation on something
specific, the [user documentation](https://black.readthedocs.io/en/latest/) is the best
place to look.

For getting started on contributing, please read the
[contributing documentation](https://black.readthedocs.org/en/latest/contributing/) for
all you need to know.

Thank you, and we look forward to your contributions!
